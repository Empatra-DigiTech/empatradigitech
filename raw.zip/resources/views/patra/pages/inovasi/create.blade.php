@extends('patra.layouts.master')
@section("title","Inovasi ~ EMPATRA DIGITECH")
@section("title_breadcumb","Inovasi")
@section('css')

@endsection
@section('breadcumb', 'Inovasi')
@section('breadcumb_child', 'Create')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="card m-b-30">
                    <div class="card-body">
                        <form action="{{ route('patra.inovasi.store') }}" method="POST" autocomplete="off"
                            onsubmit="confirm('Apakah anda yakin ingin mengirim data ini?')" enctype="multipart/form-data">
                            @csrf
                            <div class="row mb-3">
                                <div class="col-lg-12">
                                    <div class="form-group row">
                                        <label class="col-md-2 col-form-label">Judul <span
                                                class="text-danger">*</span></label>
                                        <div class="col-md-10">
                                            <input type="text" class="form-control" name="title" placeholder="Judul"
                                                value="{{ old('title') }}" required>
                                        </div>
                                    </div>
                                    <div class="form-group row mb-5">
                                        <label class="col-md-2 col-form-label" for="description">Deskripsi <span
                                                class="text-danger">*</span></label>
                                        <div class="col-md-10">
                                            @trix(\App\Models\Inovasi::class, 'content')
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2 col-form-label">Tanggal<span
                                                class="text-danger">*</span></label>
                                        <div class="col-md-10">
                                            <input type="date" class="form-control" name="date" placeholder="Tanggal"
                                                value="{{ old('date', date('l,d F Y')) }}" required>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2 col-form-label">Kategori</label>
                                        <div class="col-md-10">
                                            <input type="text" class="form-control" name="kategori" placeholder="Kategori"
                                                value="{{ old('kategori') }}">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-md-2 col-form-label">Harga</label>
                                        <div class="col-md-10">
                                            <div class="input-group">
                                                <span class="input-group-text">Rp</span>
                                                <input type="number" step="0.01" min="0" class="form-control" name="harga"
                                                    placeholder="Harga" value="{{ old('harga') }}">
                                            </div>
                                            <small class="text-muted">Kosongkan jika produk tidak memiliki harga tetap</small>
                                        </div>
                                    </div>
                                    <div class="form-group row mt-5">
                                        <label class="col-md-2 col-form-label">Image <span
                                                class="text-danger">*</span></label>
                                        <div class="col-md-10">
                                            <input class="form-control" type="file" name="image" accept="image/*"
                                                required>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <a href="{{ route('patra.inovasi.index') }}" class="btn btn-warning"><i
                                            class="fa fa-arrow-left"></i> Kembali</a>
                                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i>
                                        Simpan</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
{{-- @section('script')
<script>
    const toolbarOptions = [
        [{ 'font': [] }],
        [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
        ['bold', 'italic'],
        [{ 'list': 'ordered'}, { 'list': 'bullet' }],
        [{ 'indent': '-1'}, { 'indent': '+1' }],
        ['link', 'image'],
        ['blockquote', 'code-block']
    ];

    const quill = new Quill('#description-editor', {
        modules: {
            toolbar: {
                container: toolbarOptions
            }
        },
        theme: 'snow' // You can also choose 'bubble'
    });
    // Handle form submission
    var form = document.querySelector('form');
    form.onsubmit = function() {
        var description = document.querySelector('input[name=description]');
        description.value = quill.root.innerHTML;
    };
</script>
@endsection --}}
